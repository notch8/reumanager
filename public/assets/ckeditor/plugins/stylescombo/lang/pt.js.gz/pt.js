/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'stylescombo', 'pt', {
	label: 'Estilo',
	panelTitle: 'Formatting Styles', // MISSING
	panelTitle1: 'Block Styles', // MISSING
	panelTitle2: 'Inline Styles', // MISSING
	panelTitle3: 'Object Styles' // MISSING
});

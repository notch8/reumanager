/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'stylescombo', 'nl', {
	label: 'Stijl',
	panelTitle: 'Opmaakstijlen',
	panelTitle1: 'Blok stijlen',
	panelTitle2: 'Inline stijlen',
	panelTitle3: 'Object stijlen'
});
